<?php

namespace ScssPhp\ScssPhp;

final class OutputStyle
{
    const EXPANDED = 'expanded';
    const COMPRESSED = 'compressed';
}
