<?php

/**
 * SCSSPHP
 *
 * @copyright 2012-2020 Leaf Corcoran
 *
 * @license http://opensource.org/licenses/MIT MIT
 *
 * @link http://scssphp.github.io/scssphp
 */

namespace ScssPhp\ScssPhp;

/**
 * SCSSPHP version
 *
 * @author Leaf Corcoran <leafot@gmail.com>
 */
class Version
{
    const VERSION = '1.10.3';
}
